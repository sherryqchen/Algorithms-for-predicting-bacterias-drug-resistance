clc; clear;
data = xlsread("Training_Data symmetry Fan.xlsx");

drug_resis = data(1:210,3);         %get training data from data set. 3 is for carb drug. 6 is for toby.
symmetry_gray = data(1:210,5);
R = data(1:210,10);
G = data(1:210,11);
B = data(1:210,12);
train= [drug_resis, symmetry_gray, R, G, B];        

drug_resis = data(211:262,3);        %get training data from data set. 3 is for carb drug. 6 is for toby.
symmetry_gray = data(211:262,5);
R = data(211:262,10);
G = data(211:262,11);
B = data(211:262,12);
test=[drug_resis, symmetry_gray, R, G, B];              %get test data from data set


points=zeros(52, 210);                      %initial an array to store the distance between test data to each training point.
small_five = zeros(52, 5);                     %initial an array to store the five smallest points.

for i=1:210                                 %find each distance of each test data to each training point.                        
    for j=1:52
        temp = train(i,3:5)-test(j,3:5);        %(i,2) only symmetry; (i,3:5) only RGB; (i, 2:5) both
        points(j,i) = norm(temp);
    end
end

label = zeros(52,1);                

correct = 0;
wrong =0;

for i=1:52                               %find the five smallest points and save the location.                       
    for j=1:5
    [m, k] = min(points(i,:));      %compare the result to know if we should put this test to 0 or 1.
    small_five(i,j) = train(k,1);
    points(i,k) = max(points(i,:));
    end
    label(i) = mode(small_five(i));
    
    if test(i,1)==label(i)          
        correct = correct+1;
    else
        wrong = wrong +1;
    end
end

result = correct/(correct+wrong)
output=[label;result];
xlswrite('Knn_RGB.xls',output)