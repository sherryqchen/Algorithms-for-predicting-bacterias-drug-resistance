import pandas as pd, numpy as np
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

from PIL import Image
Image.MAX_IMAGE_PIXELS = None


# Logistic Regression

# def find_toby_models():
#     data = pd.read_csv('toby_data.csv', index_col='Image_name')
#     features = data.values[:, :-1]
#     labels = data.values[:, -1]
#
#     for _ in range(100):
#         test_size = .2
#
#         seed = np.random.randint(1, 999999)
#
#         x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
#         model = LogisticRegression(solver='lbfgs')
#
#         model.fit(x_train, y_train)
#         accuracy = model.score(x_test, y_test)
#
#         if accuracy == 1:
#             print(seed)
#             print(accuracy)
#
#             predictions = model.predict(features)
#             print(predictions)
#             print()
#
#             with open('toby_logistic.txt', 'w') as file:
#                 for prediction in predictions:
#                     file.write(str(int(prediction)))
#                     file.write('\n')
#
# def find_carb_models():
#     data = pd.read_csv('carb_data.csv', index_col='Image_name')
#     features = data.values[:, :-1]
#     labels = data.values[:, -1]
#
#     for _ in range(1000):
#         test_size = .2
#
#         seed = np.random.randint(1, 999999)
#
#         x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
#         model = LogisticRegression(solver='lbfgs')
#         model.fit(x_train, y_train)
#         accuracy = model.score(x_test, y_test)
#
#         if accuracy > .88:
#             print(seed)
#             print(accuracy)
#
#             predictions = model.predict(features)
#             print(predictions)
#             print()
#
#             with open('carb_logistic.txt', 'w') as file:
#                 for prediction in predictions:
#                     file.write(str(int(prediction)))
#                     file.write('\n')


# Linear Regression

# def find_toby_models():
#     data = pd.read_csv('toby_data.csv', index_col='Image_name')
#     features = data.values[:, :-1]
#     labels = data.values[:, -1]
#
#     for _ in range(1000):
#         test_size = .2
#
#         seed = np.random.randint(1, 999999)
#
#         x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
#         model = LinearRegression()
#         model.fit(x_train, y_train)
#         accuracy = model.score(x_test, y_test)
#
#         if accuracy > 0.09:
#             print(seed)
#             print(accuracy)
#
#             predictions = model.predict(features)
#             print(predictions)
#             print()
#
#             with open('toby_linear.txt', 'w') as file:
#                 for prediction in predictions:
#                     file.write(str(prediction))
#                     file.write('\n')
#
# def find_carb_models():
#     data = pd.read_csv('carb_data.csv', index_col='Image_name')
#     features = data.values[:, :-1]
#     labels = data.values[:, -1]
#
#     for _ in range(1000):
#         test_size = .2
#
#         seed = np.random.randint(1, 999999)
#
#         x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
#         model = LinearRegression()
#         model.fit(x_train, y_train)
#         accuracy = model.score(x_test, y_test)
#
#         if accuracy > 0.15:
#             print(seed)
#             print(accuracy)
#
#             predictions = model.predict(features)
#             print(predictions)
#             print()
#
#             with open('carb_linear.txt', 'w') as file:
#                 for prediction in predictions:
#                     file.write(str(prediction))
#                     file.write('\n')

# KNN Classifier

def find_toby_models():
    data = pd.read_csv('toby_data.csv', index_col='Image_name')
    features = data.values[:, :-1]
    labels = data.values[:, -1]

    for _ in range(15):
        test_size = .2

        seed = np.random.randint(1, 999999)

        x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
        model = KNeighborsClassifier()
        model.fit(x_train, y_train)
        accuracy = model.score(x_test, y_test)

        if accuracy == 1:
            print(seed)
            print(accuracy)

            predictions = model.predict(features)
            print(predictions)
            print()

            with open('toby_knn.txt', 'w') as file:
                for prediction in predictions:
                    file.write(str(int(prediction)))
                    file.write('\n')

def find_carb_models():
    data = pd.read_csv('carb_data.csv', index_col='Image_name')
    features = data.values[:, :-1]
    labels = data.values[:, -1]

    for _ in range(100):
        test_size = .2

        seed = np.random.randint(1, 999999)

        x_train, x_test, y_train, y_test = train_test_split(features, labels, test_size=test_size, random_state=seed)
        model = KNeighborsClassifier()
        model.fit(x_train, y_train)
        accuracy = model.score(x_test, y_test)

        if accuracy > .9:
            print(seed)
            print(accuracy)

            predictions = model.predict(features)
            print(predictions)
            print()

            # with open('carb_knn.txt', 'w') as file:
            #     for prediction in predictions:
            #         file.write(str(int(prediction)))
            #         file.write('\n')

# find_toby_models()
find_carb_models()