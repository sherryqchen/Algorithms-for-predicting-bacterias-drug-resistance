clc; clear;
data = xlsread("Training_Data symmetry Fan.xlsx");

drug_resis = data(1:210,3);         %get training data from data set. 3 is for carb drug. 6 is for toby.
symmetry_gray = data(1:210,5);
R = data(1:210,10);
G = data(1:210,11);
B = data(1:210,12);
train= [drug_resis, symmetry_gray, R, G, B];        

drug_resis = data(211:262,3);           %get testing data from data set. 3 is for carb drug. 6 is for toby.
symmetry_gray = data(211:262,5);
R = data(211:262,10);
G = data(211:262,11);
B = data(211:262,12);
test=[drug_resis, symmetry_gray, R, G, B];


X = train(1:210,2:5);           %try the different feature here. (1:210,2) only symmetry; ((1:210,3:5)) only RGB; (1:210,2:5) both
y = train(:,1);
Bt = (inv(X'*X))*X'*y;

result = test(1:52,2:5)*Bt;     %(1:210,2) only symmetry; ((1:210,3:5)) only RGB; (1:210,2:5) both
stand = 0.9;
correct = zeros(52,12);
result_data = zeros(52,12);
counter = 0;

for i = 1:length(result)
    for j = 0.4:0.05:stand
        counter=counter+1;
        if result(i)>j            
           result_data(i,counter)=1;
        else
           result_data(i,counter)=0;
        end
    end
    counter = 0;
end

accuracy = zeros(1,12);

for i=1:12
    accuracy(1,i) = sum(result_data(:,i))/52;
end

output=[result_data;accuracy];
xlswrite('Linear_grayandRGB.xls',output)